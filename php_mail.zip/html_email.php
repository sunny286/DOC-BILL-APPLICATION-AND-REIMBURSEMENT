<?php
	//Html Email 
	
	$to = 'your email id';
	$subject = 'Html Content in PHP Email';
	$message = '<h1>This is simple text email in php</h1><br/> <h4>Welcome to Free Tech Guru</h4><br/>In this channel you will get all the programming tutorials';
	
	$header = "From:info@freetechguru.com \r\n";  
	$header .= "MIME-Version: 1.0 \r\n";  
	$header .= "Content-type: text/html;charset=UTF-8 \r\n";
	
	if(mail($to,$subject,$message,$header))
	{
		echo 'Email Sent Successfully!';
	}
	else
	{
		echo 'Email Not Sent';
	}
?>