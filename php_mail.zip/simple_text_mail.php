<?php
	//Simple Text mail
	
	$to = 'your email id';
	$subject = 'Simple Text PHP Email';
	$message = 'This is simple text email in php<br/> Welcome to Free Tech Guru';
	
	if(mail($to,$subject,$message))
	{
		echo 'Email Sent Successfully';
	}
	else
	{
		echo 'Email not sent';
	}
	
?>