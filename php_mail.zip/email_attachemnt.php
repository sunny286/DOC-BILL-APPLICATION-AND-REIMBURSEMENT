<?php
	//Mail with attachment
	
	$file = 'test.txt';
	
	$to = 'your email id';
	$subject = 'PHP Email With File Attachment';
	$message = '<h1>This is simple text email in php</h1><br/> <h4>Welcome to Free Tech Guru</h4><br/>Please check the attachement below.';
	
	$uId = md5(uniqid(time()));
	
	$header = "From:info@ftg.com \r\n";
	$header .= "Reply-To: reply@ftg.com \r\n";
	$header .= "MIME-Version: 1.0 \r\n";  
	$header .= "Content-Type: multipart/mixed; boundary=\"".$uId."\"\r\n\r\n";
	
	$msg = "--".$uId."\r\n";
	$msg .= "Content-type:text/html;charset=UTF-8" . "\r\n";
	$msg .= "Content-type:text/plain; charset=iso-8859-1\r\n";
	$msg .= "Content-Transfer-Encoding: 7bit\r\n\r\n";
	$msg .= $message."\r\n\r\n";
	$msg .= "--".$uId."\r\n";
	$msg .= "Content-Type: application/octet-stream; name=\"".$file."\"\r\n"; 
	$msg .= "Content-Transfer-Encoding: base64\r\n";
	$msg .= "Content-Disposition: attachment; filename=\"".$file."\"\r\n\r\n";
	$msg .= $content."\r\n\r\n";
	$msg .= "--".$uId."--";
			
	if(mail($to, $subject, $msg, $header))
	{
		echo 'Attachment Email Sent Successfully';
	}
	else
	{
		'Email not sent';
	}
?>