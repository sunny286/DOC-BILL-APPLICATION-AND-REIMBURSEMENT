<?php
	echo 'How to send email in php?';
?>